#!/bin/bash
# The thirteen separate scripts in this folder can run at once using:
# sh find_dealer_run_scripts.sh > Dealers_working_during_losses 

sh find_dealer_310_5am.sh
sh find_dealer_310_8am.sh
sh find_dealer_310_2pm.sh
sh find_dealer_310_8pm.sh
sh find_dealer_310_11pm.sh
sh find_dealer_312_5am.sh
sh find_dealer_312_8am.sh
sh find_dealer_312_2pm.sh
sh find_dealer_312_8pm.sh
sh find_dealer_312_11pm.sh
sh find_dealer_315_5am.sh
sh find_dealer_315_8am.sh
sh find_dealer_315_2pm.sh