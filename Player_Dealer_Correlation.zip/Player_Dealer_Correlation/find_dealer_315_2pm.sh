#!/bin/bash
awk -F" " '{print FILENAME, $1,$2,$5,$6 " - Roulette dealer"}' 0315*.txt | grep -h '11:00:00 PM'
