#!/bin/bash
awk -F" " '{print FILENAME, $1,$2,$5,$6 " - Roulette dealer"}' 0315*.txt | grep -h '05:00:00 AM'