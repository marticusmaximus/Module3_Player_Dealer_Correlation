#!/bin/usr/env bash
# check for three arguments being entered
arguments=$#;
if [ $arguments -ne 3 ]; then echo "You must enter three valid arguments e.g. 0310 11am blackjack"; exit; fi
# Define date variable, check for 4 digits
date_code=$1 # $(echo $1)# | grep -oE '[0-9]{4}');
# Tricky to split the time input up e.g. 7am
# Use grep and regex to split time argument and create two variables, for time and am/pm
time_hour=$(echo $2 | grep -oE '[0-9]{1,2}'); #gets the two digits for hour
# Prepend a zero if just one digit is given (l=1)
if [ ${#time_hour} -eq 1 ]; then time_hour="0"$time_hour; fi;
# Split am/pm  and convert to upper case
time_ampm=$(echo $2 | tr '[:lower:]' '[:upper:]' | grep -oE '(AM|PM)');
# Create valid regex for grep search of time
time_regex="\s"$time_hour".*"$time_ampm;
# Get game columns required, as lower-case string
game_test=$(echo $3 | tr '[:upper:]' '[:lower:]');
# Get relevant column number for awk
#echo $game_test | grep -E -o "^[a-z]*"
# exit;
if [ $game_test = "blackjack" ]; then game_col1=3;
    elif [ $game_test = "roulette" ]; then game_col1=5;
    elif [ $game_test = "texas" ]; then game_col1=7; 
    else echo "Please enter blackjack, roulette or texas as the game argument"; exit;
fi
# Variable for appropriate surname column
game_col2=$(($game_col1+1));
# Read file requested via 4 digit date argument and search for time argument.
# Prepend filename to confirm the correct record is read
# Search inside subfolders in case the dealer schedules are not in this directory
find -type f -iname *$date_code*Dealer_schedule.txt -exec awk -F" " '{print FILENAME, " " $1,$2," "$'$game_col1',$'$game_col2'" '$3'-dealer"}' {} \; | grep -i -h -E $time_regex