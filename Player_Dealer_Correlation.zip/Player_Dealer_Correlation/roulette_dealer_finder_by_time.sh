#!/bin/bash
# check for two arguments being entered
arguments=$#;
if [ $arguments -ne 2 ]; then echo "You must enter two valid arguments e.g. 0310 11am"; exit; fi
# Tricky to split the time input up e.g. 7am
# Use grep and regex to split time argument and create two variables, for time and am/pm
time_hour=$(echo $2 | grep -oE '[0-9]{1,2}'); #gets the two digits for hour
# Prepend a zero if just one digit is given
if [ ${#time_hour} -eq 1 ]; then time_hour="0"$time_hour; else time_hour=$time_hour; fi
# Split am/pm  and convert to upper case
time_ampm=$(echo $2 | tr '[:lower:]' '[:upper:]' | grep -oE '(AM|PM)');
# Create valid regex for grep search
time_regex="\s"$time_hour".*"$time_ampm;
# Read file requested via 4 digit date argument and search for time argument.
# Prepend filename to confirm the correct record is read
find -type f -iname *$1*Dealer_schedule.txt -exec awk -F" " '{print FILENAME, " " $1,$2,$5,$6 " - Roulette dealer"}' {} \; | grep -h -E $time_regex;

