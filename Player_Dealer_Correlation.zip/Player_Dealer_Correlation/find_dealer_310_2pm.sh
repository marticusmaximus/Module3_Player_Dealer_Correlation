#!/bin/bash
awk -F" " '{print FILENAME, $1,$2,$5,$6 " - Roulette dealer"}' 0310*.txt | grep -h '02:00:00 PM'