#!/bin/bash
awk -F" " '{print FILENAME, $1,$2,$5,$6 " - Roulette dealer"}' 0310*.txt | grep -h '08:00:00 PM'
